// ============================================================
//  ONLINE FPS ARENA — SERVER
//  Node.js + Express + Socket.io
//  Отвечает за: подключение игроков, распределение по командам,
//  синхронизацию позиций, стрельбу, урон, респавн, счёт.
//  НИКАКИХ БОТОВ — только реальные подключённые игроки.
// ============================================================

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

const PORT = process.env.PORT || 3000;

// Раздаём клиентскую часть как статику (удобно для локального теста
// и для деплоя клиента+сервера вместе на Render/Railway).
app.use(express.static(path.join(__dirname, '..', 'client')));

// ---------------- Игровое состояние ----------------
const TEAMS = { CT: 'CT', T: 'T' };
const MAX_HEALTH = 100;
const RESPAWN_TIME_MS = 3000;

// Точки спавна для команд (можно расширить под свою карту)
const SPAWN_POINTS = {
  CT: [
    { x: -10, y: 1.7, z: -10 },
    { x: -8, y: 1.7, z: -12 },
    { x: -12, y: 1.7, z: -8 }
  ],
  T: [
    { x: 10, y: 1.7, z: 10 },
    { x: 8, y: 1.7, z: 12 },
    { x: 12, y: 1.7, z: 8 }
  ]
};

function randomSpawn(team) {
  const points = SPAWN_POINTS[team];
  return points[Math.floor(Math.random() * points.length)];
}

// players[socket.id] = {
//   id, name, team, x, y, z, rotY, health, alive, kills, deaths
// }
const players = {};
const score = { CT: 0, T: 0 };

function teamCounts() {
  let ct = 0, t = 0;
  for (const id in players) {
    if (players[id].team === TEAMS.CT) ct++;
    else if (players[id].team === TEAMS.T) t++;
  }
  return { ct, t };
}

function publicState() {
  return { players, score };
}

io.on('connection', (socket) => {
  console.log('Игрок подключился:', socket.id);

  // Игрок присылает своё имя и выбранную команду (или "auto")
  socket.on('join', ({ name, team }) => {
    const counts = teamCounts();
    let finalTeam = team;

    if (finalTeam !== TEAMS.CT && finalTeam !== TEAMS.T) {
      // авто-баланс, если игрок не выбрал команду явно
      finalTeam = counts.ct <= counts.t ? TEAMS.CT : TEAMS.T;
    }

    const spawn = randomSpawn(finalTeam);

    players[socket.id] = {
      id: socket.id,
      name: (name || 'Player').substring(0, 16),
      team: finalTeam,
      x: spawn.x, y: spawn.y, z: spawn.z,
      rotY: 0,
      health: MAX_HEALTH,
      alive: true,
      kills: 0,
      deaths: 0
    };

    socket.emit('joined', { id: socket.id, team: finalTeam, state: publicState() });
    socket.broadcast.emit('player_joined', players[socket.id]);
    io.emit('team_counts', teamCounts());
  });

  // Обновление позиции/поворота (клиент шлёт часто, ~15-20 раз/сек)
  socket.on('move', (data) => {
    const p = players[socket.id];
    if (!p || !p.alive) return;
    p.x = data.x;
    p.y = data.y;
    p.z = data.z;
    p.rotY = data.rotY;
    socket.broadcast.emit('player_moved', {
      id: socket.id, x: p.x, y: p.y, z: p.z, rotY: p.rotY
    });
  });

  // Выстрел: клиент сам считает попадание рейкастом и присылает
  // id цели (упрощённая, но честная модель без физики на сервере)
  socket.on('shoot', ({ targetId, damage }) => {
    const shooter = players[socket.id];
    const target = players[targetId];
    if (!shooter || !target || !shooter.alive || !target.alive) return;
    if (shooter.team === target.team) return; // без "тим-килла"

    target.health -= damage || 25;
    io.emit('player_damaged', { id: targetId, health: target.health });

    if (target.health <= 0) {
      target.alive = false;
      target.deaths++;
      shooter.kills++;
      score[shooter.team]++;

      io.emit('player_killed', {
        victim: targetId,
        killer: socket.id,
        score
      });

      setTimeout(() => {
        if (!players[targetId]) return; // отключился
        const spawn = randomSpawn(target.team);
        target.health = MAX_HEALTH;
        target.alive = true;
        target.x = spawn.x;
        target.y = spawn.y;
        target.z = spawn.z;
        io.emit('player_respawned', target);
      }, RESPAWN_TIME_MS);
    }
  });

  socket.on('chat', (msg) => {
    const p = players[socket.id];
    if (!p) return;
    io.emit('chat', { name: p.name, team: p.team, text: String(msg).substring(0, 200) });
  });

  socket.on('disconnect', () => {
    delete players[socket.id];
    io.emit('player_left', socket.id);
    io.emit('team_counts', teamCounts());
    console.log('Игрок отключился:', socket.id);
  });
});

server.listen(PORT, () => {
  console.log(`Сервер запущен на порту ${PORT}`);
});
