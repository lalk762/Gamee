// ============================================================
//  ONLINE FPS ARENA — SERVER
//  Node.js + Express + Socket.io
//  Отвечает за: подключение игроков, распределение по командам,
//  синхронизацию позиций, стрельбу, урон, респавн, счёт, раунды.
//  НИКАКИХ БОТОВ — только реальные подключённые игроки.
// ============================================================

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const PORT = process.env.PORT || 3000;

// Раздаём клиентскую часть (папка docs — совместимо с GitHub Pages,
// если решишь хостить всё на одном сервере).
app.use(express.static(path.join(__dirname, '..', 'docs')));

// ---------------- Игровое состояние ----------------
const TEAMS = { CT: 'CT', T: 'T' };
const MAX_HEALTH = 100;
const RESPAWN_TIME_MS = 3000;
const ROUND_TIME_MS = 3 * 60 * 1000; // 3 минуты на раунд, потом счёт обнуляется

const SPAWN_POINTS = {
  CT: [
    { x: -10, y: 1.7, z: -10 }, { x: -8, y: 1.7, z: -12 }, { x: -12, y: 1.7, z: -8 }
  ],
  T: [
    { x: 10, y: 1.7, z: 10 }, { x: 8, y: 1.7, z: 12 }, { x: 12, y: 1.7, z: 8 }
  ]
};

function randomSpawn(team) {
  const points = SPAWN_POINTS[team];
  return points[Math.floor(Math.random() * points.length)];
}

const players = {};
const score = { CT: 0, T: 0 };
let roundEndsAt = Date.now() + ROUND_TIME_MS;

function teamCounts() {
  let ct = 0, t = 0;
  for (const id in players) {
    if (players[id].team === TEAMS.CT) ct++;
    else if (players[id].team === TEAMS.T) t++;
  }
  return { ct, t };
}

function publicState() {
  return { players, score, roundEndsAt };
}

// Таймер раундов
setInterval(() => {
  if (Date.now() >= roundEndsAt) {
    const winner = score.CT === score.T ? 'Ничья' : (score.CT > score.T ? 'CT' : 'T');
    io.emit('round_end', { winner, score: { ...score } });
    score.CT = 0;
    score.T = 0;
    roundEndsAt = Date.now() + ROUND_TIME_MS;
    // респавн всех живых на местах команд для нового раунда
    for (const id in players) {
      const p = players[id];
      const spawn = randomSpawn(p.team);
      p.health = MAX_HEALTH;
      p.alive = true;
      p.x = spawn.x; p.y = spawn.y; p.z = spawn.z;
    }
    io.emit('new_round', { players, roundEndsAt });
  }
}, 1000);

io.on('connection', (socket) => {
  console.log('Игрок подключился:', socket.id);

  socket.on('join', ({ name, team }) => {
    const counts = teamCounts();
    let finalTeam = team;
    if (finalTeam !== TEAMS.CT && finalTeam !== TEAMS.T) {
      finalTeam = counts.ct <= counts.t ? TEAMS.CT : TEAMS.T;
    }
    const spawn = randomSpawn(finalTeam);

    players[socket.id] = {
      id: socket.id,
      name: (name || 'Player').substring(0, 16),
      team: finalTeam,
      x: spawn.x, y: spawn.y, z: spawn.z,
      rotY: 0,
      health: MAX_HEALTH,
      alive: true,
      kills: 0,
      deaths: 0
    };

    socket.emit('joined', { id: socket.id, team: finalTeam, state: publicState() });
    socket.broadcast.emit('player_joined', players[socket.id]);
    io.emit('team_counts', teamCounts());
  });

  socket.on('move', (data) => {
    const p = players[socket.id];
    if (!p || !p.alive) return;
    p.x = data.x; p.y = data.y; p.z = data.z; p.rotY = data.rotY;
    socket.broadcast.emit('player_moved', { id: socket.id, x: p.x, y: p.y, z: p.z, rotY: p.rotY });
  });

  socket.on('shoot', ({ targetId, damage }) => {
    const shooter = players[socket.id];
    const target = players[targetId];
    if (!shooter || !target || !shooter.alive || !target.alive) return;
    if (shooter.team === target.team) return;

    target.health -= damage || 25;
    io.emit('player_damaged', { id: targetId, health: target.health, by: socket.id });

    if (target.health <= 0) {
      target.alive = false;
      target.deaths++;
      shooter.kills++;
      score[shooter.team]++;

      io.emit('player_killed', { victim: targetId, killer: socket.id, score });

      setTimeout(() => {
        if (!players[targetId]) return;
        const spawn = randomSpawn(target.team);
        target.health = MAX_HEALTH;
        target.alive = true;
        target.x = spawn.x; target.y = spawn.y; target.z = spawn.z;
        io.emit('player_respawned', target);
      }, RESPAWN_TIME_MS);
    }
  });

  socket.on('chat', (msg) => {
    const p = players[socket.id];
    if (!p) return;
    io.emit('chat', { name: p.name, team: p.team, text: String(msg).substring(0, 200) });
  });

  socket.on('disconnect', () => {
    delete players[socket.id];
    io.emit('player_left', socket.id);
    io.emit('team_counts', teamCounts());
    console.log('Игрок отключился:', socket.id);
  });
});

server.listen(PORT, () => {
  console.log(`Сервер запущен на порту ${PORT}`);
});
