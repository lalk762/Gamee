// ============================================================
//  ONLINE FPS ARENA — CLIENT
//  Three.js (рендер) + Socket.io (сеть)
// ============================================================

// ---------- Подключение к серверу ----------
// Если клиент и сервер запущены с одного адреса (Render/Railway),
// io() сам подключится к текущему хосту.
// Если сервер отдельно (например, при хостинге клиента на GitHub Pages),
// впиши сюда полный адрес сервера, например:
// const socket = io('https://твой-сервер.onrender.com');
const socket = io();

let myId = null;
let myTeam = null;
const otherPlayers = {}; // id -> { mesh, nameSprite, data }

// ---------- UI: меню выбора команды ----------
const menu = document.getElementById('menu');
const nameInput = document.getElementById('nameInput');
const playBtn = document.getElementById('playBtn');
const teamCountsEl = document.getElementById('teamCounts');
let selectedTeam = null;

document.querySelectorAll('.teamBtn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.teamBtn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    selectedTeam = btn.dataset.team;
  });
});

socket.on('team_counts', (counts) => {
  teamCountsEl.textContent = `CT: ${counts.ct} · T: ${counts.t}`;
});

playBtn.addEventListener('click', () => {
  const name = nameInput.value.trim() || ('Player' + Math.floor(Math.random() * 1000));
  socket.emit('join', { name, team: selectedTeam || 'auto' });
});

// ---------- Three.js базовая сцена ----------
const scene = new THREE.Scene();
scene.background = new THREE.Color(0xbfd9ff);
scene.fog = new THREE.Fog(0xbfd9ff, 20, 120);

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 1.7, 0);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
document.body.appendChild(renderer.domElement);

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

// ---------- Освещение ----------
const hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 0.9);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffffff, 1.0);
sun.position.set(30, 50, 20);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -60;
sun.shadow.camera.right = 60;
sun.shadow.camera.top = 60;
sun.shadow.camera.bottom = -60;
scene.add(sun);

// ---------- Арена (простая карта: пол, стены, ящики-укрытия) ----------
const groundMat = new THREE.MeshStandardMaterial({ color: 0xd8c9a3 });
const ground = new THREE.Mesh(new THREE.PlaneGeometry(120, 120), groundMat);
ground.rotation.x = -Math.PI / 2;
ground.receiveShadow = true;
scene.add(ground);

const wallMat = new THREE.MeshStandardMaterial({ color: 0xcbb98a });
function addWall(x, z, w, d, h = 6) {
  const wall = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), wallMat);
  wall.position.set(x, h / 2, z);
  wall.castShadow = true;
  wall.receiveShadow = true;
  scene.add(wall);
  return wall;
}
// периметр
addWall(0, -60, 120, 2);
addWall(0, 60, 120, 2);
addWall(-60, 0, 2, 120);
addWall(60, 0, 2, 120);
// укрытия по центру
const crateMat = new THREE.MeshStandardMaterial({ color: 0xa9834f });
const cratePositions = [
  [0, 0], [8, 5], [-8, -5], [15, -10], [-15, 10], [5, -15], [-5, 15], [20, 0], [-20, 0]
];
const obstacles = [];
cratePositions.forEach(([x, z]) => {
  const size = 2.5 + Math.random() * 1.5;
  const crate = new THREE.Mesh(new THREE.BoxGeometry(size, size, size), crateMat);
  crate.position.set(x, size / 2, z);
  crate.castShadow = true;
  crate.receiveShadow = true;
  scene.add(crate);
  obstacles.push(crate);
});

// визуальные маркеры точек спавна команд (просто для красоты/ориентира)
function addSpawnMarker(x, z, color) {
  const marker = new THREE.Mesh(
    new THREE.CylinderGeometry(3, 3, 0.1, 24),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.35 })
  );
  marker.position.set(x, 0.06, z);
  scene.add(marker);
}
addSpawnMarker(-10, -10, 0x5aa9ff);
addSpawnMarker(10, 10, 0xffb15a);

// ---------- Модель оружия от первого лица (упрощённая) ----------
const gunGroup = new THREE.Group();
const gunMat = new THREE.MeshStandardMaterial({ color: 0x222222 });
const gunBody = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.15, 0.6), gunMat);
gunBody.position.set(0.25, -0.25, -0.6);
gunGroup.add(gunBody);
camera.add(gunGroup);
scene.add(camera);

// ---------- Управление (Pointer Lock, WASD) ----------
let pitch = 0, yaw = 0;
const keys = {};
let velocityY = 0;
const moveSpeed = 6;
let canShoot = true;
let isAlive = false;

document.addEventListener('keydown', e => keys[e.code] = true);
document.addEventListener('keyup', e => keys[e.code] = false);

renderer.domElement.addEventListener('click', () => {
  if (isAlive) renderer.domElement.requestPointerLock();
});

document.addEventListener('mousemove', (e) => {
  if (document.pointerLockElement !== renderer.domElement) return;
  const sensitivity = 0.0022;
  yaw -= e.movementX * sensitivity;
  pitch -= e.movementY * sensitivity;
  pitch = Math.max(-Math.PI / 2 + 0.01, Math.min(Math.PI / 2 - 0.01, pitch));
  camera.rotation.order = 'YXZ';
  camera.rotation.y = yaw;
  camera.rotation.x = pitch;
});

document.addEventListener('mousedown', (e) => {
  if (e.button !== 0) return;
  if (document.pointerLockElement !== renderer.domElement) return;
  shoot();
});

function collides(x, z) {
  for (const o of obstacles) {
    const dx = Math.abs(x - o.position.x);
    const dz = Math.abs(z - o.position.z);
    const half = o.geometry.parameters.width / 2 + 0.5;
    if (dx < half && dz < half) return true;
  }
  if (x < -58 || x > 58 || z < -58 || z > 58) return true;
  return false;
}

function updateMovement(dt) {
  if (!isAlive) return;
  const forward = new THREE.Vector3(Math.sin(yaw), 0, Math.cos(yaw)).multiplyScalar(-1);
  const right = new THREE.Vector3(Math.sin(yaw + Math.PI / 2), 0, Math.cos(yaw + Math.PI / 2)).multiplyScalar(-1);

  let move = new THREE.Vector3();
  if (keys['KeyW']) move.add(forward);
  if (keys['KeyS']) move.sub(forward);
  if (keys['KeyA']) move.sub(right);
  if (keys['KeyD']) move.add(right);
  if (move.lengthSq() > 0) move.normalize().multiplyScalar(moveSpeed * dt);

  const newX = camera.position.x + move.x;
  const newZ = camera.position.z + move.z;
  if (!collides(newX, camera.position.z)) camera.position.x = newX;
  if (!collides(camera.position.x, newZ)) camera.position.z = newZ;

  socket.emit('move', {
    x: camera.position.x, y: camera.position.y, z: camera.position.z, rotY: yaw
  });
}

// ---------- Стрельба (клиентский рейкаст) ----------
const raycaster = new THREE.Raycaster();
function shoot() {
  if (!canShoot || !isAlive) return;
  canShoot = false;
  setTimeout(() => canShoot = true, 150); // скорострельность

  // маленький "выстрел" — дульная вспышка
  flashMuzzle();

  raycaster.setFromCamera({ x: 0, y: 0 }, camera);
  const targets = Object.values(otherPlayers).map(p => p.mesh);
  const hits = raycaster.intersectObjects(targets, true);
  if (hits.length > 0) {
    let obj = hits[0].object;
    while (obj.parent && !obj.userData.playerId) obj = obj.parent;
    const targetId = obj.userData.playerId;
    if (targetId) {
      socket.emit('shoot', { targetId, damage: 25 });
    }
  }
}

function flashMuzzle() {
  gunBody.material.emissive = new THREE.Color(0xffaa00);
  setTimeout(() => { gunBody.material.emissive = new THREE.Color(0x000000); }, 60);
}

// ---------- Отрисовка других игроков ----------
function createPlayerMesh(team) {
  const color = team === 'CT' ? 0x5aa9ff : 0xffb15a;
  const group = new THREE.Group();

  const body = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.4, 1.2, 4, 8),
    new THREE.MeshStandardMaterial({ color })
  );
  body.position.y = 1.0;
  body.castShadow = true;
  group.add(body);

  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.3, 12, 12),
    new THREE.MeshStandardMaterial({ color: 0xffdbac })
  );
  head.position.y = 1.85;
  head.castShadow = true;
  group.add(head);

  return group;
}

function addOrUpdatePlayer(p) {
  if (p.id === myId) return;
  if (!otherPlayers[p.id]) {
    const mesh = createPlayerMesh(p.team);
    mesh.userData.playerId = p.id;
    mesh.traverse(o => o.userData.playerId = p.id);
    scene.add(mesh);
    otherPlayers[p.id] = { mesh, data: p };
  }
  const entry = otherPlayers[p.id];
  entry.data = p;
  entry.mesh.position.set(p.x, 0, p.z);
  entry.mesh.rotation.y = p.rotY;
  entry.mesh.visible = p.alive;
}

function removePlayer(id) {
  const entry = otherPlayers[id];
  if (entry) {
    scene.remove(entry.mesh);
    delete otherPlayers[id];
  }
}

// ---------- HUD ----------
const hpVal = document.getElementById('hpVal');
const scoreCTEl = document.getElementById('scoreCT');
const scoreTEl = document.getElementById('scoreT');
const killfeed = document.getElementById('killfeed');
const hud = document.getElementById('hud');

function addKillFeed(text) {
  const line = document.createElement('div');
  line.textContent = text;
  killfeed.prepend(line);
  setTimeout(() => line.remove(), 5000);
}

// ---------- Чат ----------
const chatBox = document.getElementById('chatBox');
const chatInput = document.getElementById('chatInput');
document.addEventListener('keydown', (e) => {
  if (e.code === 'Enter') {
    if (chatInput.style.display === 'block') {
      if (chatInput.value.trim()) socket.emit('chat', chatInput.value.trim());
      chatInput.value = '';
      chatInput.style.display = 'none';
      renderer.domElement.requestPointerLock();
    } else if (isAlive) {
      chatInput.style.display = 'block';
      chatInput.focus();
    }
  }
});
socket.on('chat', ({ name, team, text }) => {
  const line = document.createElement('div');
  line.style.color = team === 'CT' ? '#5aa9ff' : '#ffb15a';
  line.textContent = `${name}: `;
  const span = document.createElement('span');
  span.style.color = '#fff';
  span.textContent = text;
  line.appendChild(span);
  chatBox.appendChild(line);
  while (chatBox.children.length > 6) chatBox.removeChild(chatBox.firstChild);
  setTimeout(() => { if (line.parentNode) line.remove(); }, 8000);
});

// ---------- Сокет-события от сервера ----------
socket.on('joined', ({ id, team, state }) => {
  myId = id;
  myTeam = team;
  isAlive = true;
  menu.style.display = 'none';

  const me = state.players[id];
  camera.position.set(me.x, me.y, me.z);
  hpVal.textContent = me.health;
  scoreCTEl.textContent = state.score.CT;
  scoreTEl.textContent = state.score.T;

  for (const pid in state.players) {
    if (pid !== id) addOrUpdatePlayer(state.players[pid]);
  }
  hud.textContent = `Ты: ${me.name} [${team}]`;
});

socket.on('player_joined', (p) => addOrUpdatePlayer(p));
socket.on('player_moved', (p) => addOrUpdatePlayer(p));
socket.on('player_left', (id) => removePlayer(id));

socket.on('player_damaged', ({ id, health }) => {
  if (id === myId) hpVal.textContent = Math.max(0, health);
  else if (otherPlayers[id]) otherPlayers[id].data.health = health;
});

socket.on('player_killed', ({ victim, killer, score }) => {
  scoreCTEl.textContent = score.CT;
  scoreTEl.textContent = score.T;
  const killerName = killer === myId ? 'Ты' : (otherPlayers[killer]?.data.name || '???');
  const victimName = victim === myId ? 'Тебя' : (otherPlayers[victim]?.data.name || '???');
  addKillFeed(`${killerName} убил ${victimName}`);

  if (victim === myId) {
    isAlive = false;
    document.exitPointerLock();
    hpVal.textContent = 0;
  } else if (otherPlayers[victim]) {
    otherPlayers[victim].mesh.visible = false;
  }
});

socket.on('player_respawned', (p) => {
  if (p.id === myId) {
    isAlive = true;
    camera.position.set(p.x, p.y, p.z);
    hpVal.textContent = p.health;
  } else if (otherPlayers[p.id]) {
    otherPlayers[p.id].mesh.visible = true;
    addOrUpdatePlayer(p);
  }
});

// ---------- Игровой цикл ----------
let last = performance.now();
function animate() {
  requestAnimationFrame(animate);
  const now = performance.now();
  const dt = Math.min((now - last) / 1000, 0.05);
  last = now;
  updateMovement(dt);
  renderer.render(scene, camera);
}
animate();
