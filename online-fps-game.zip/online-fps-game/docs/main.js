// ============================================================
//  ONLINE FPS ARENA — CLIENT v2
//  Three.js (рендер) + Socket.io (сеть) + WebAudio (звук)
// ============================================================

// ---------- Подключение к серверу ----------
// Если сервер и клиент на одном хосте — оставь io().
// Если клиент лежит отдельно (GitHub Pages), впиши адрес сервера:
// const socket = io('https://твой-сервер.onrender.com');
const socket = io({ reconnectionAttempts: 5 });

const connStatus = document.getElementById('connStatus');
socket.on('connect', () => { connStatus.textContent = 'подключено ✓'; connStatus.style.color = '#2ecc71'; });
socket.on('connect_error', () => { connStatus.textContent = 'нет связи с сервером — проверь, запущен ли server.js'; connStatus.style.color = '#ff5050'; });
socket.on('disconnect', () => { connStatus.textContent = 'соединение потеряно...'; connStatus.style.color = '#ff5050'; });

let myId = null;
let myTeam = null;
let myName = '';
const otherPlayers = {}; // id -> { mesh, data }

// ---------- Звук (синтез через WebAudio, без внешних файлов) ----------
const actx = new (window.AudioContext || window.webkitAudioContext)();
function beep(freq, duration, type = 'square', vol = 0.15) {
  const osc = actx.createOscillator();
  const gain = actx.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  gain.gain.value = vol;
  osc.connect(gain).connect(actx.destination);
  osc.start();
  gain.gain.exponentialRampToValueAtTime(0.001, actx.currentTime + duration);
  osc.stop(actx.currentTime + duration);
}
function sfxShoot() { beep(180, 0.08, 'sawtooth', 0.12); beep(90, 0.12, 'square', 0.08); }
function sfxHit() { beep(700, 0.06, 'square', 0.1); }
function sfxKill() { beep(440, 0.1, 'triangle', 0.15); setTimeout(() => beep(660, 0.15, 'triangle', 0.15), 90); }
function sfxDamage() { beep(120, 0.15, 'sawtooth', 0.18); }
function sfxRespawn() { beep(300, 0.1, 'sine', 0.1); setTimeout(() => beep(500, 0.15, 'sine', 0.1), 100); }

// ---------- UI: меню выбора команды ----------
const menu = document.getElementById('menu');
const nameInput = document.getElementById('nameInput');
const playBtn = document.getElementById('playBtn');
const teamCountsEl = document.getElementById('teamCounts');
let selectedTeam = null;

document.querySelectorAll('.teamBtn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.teamBtn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    selectedTeam = btn.dataset.team;
  });
});

socket.on('team_counts', (counts) => {
  teamCountsEl.textContent = `CT: ${counts.ct} · T: ${counts.t}`;
});

playBtn.addEventListener('click', () => {
  actx.resume();
  myName = nameInput.value.trim() || ('Player' + Math.floor(Math.random() * 1000));
  socket.emit('join', { name: myName, team: selectedTeam || 'auto' });
});

// ---------- Three.js базовая сцена ----------
const scene = new THREE.Scene();

// Градиентное небо через canvas-текстуру (без внешних картинок)
function makeSkyTexture() {
  const c = document.createElement('canvas');
  c.width = 2; c.height = 256;
  const ctx = c.getContext('2d');
  const grad = ctx.createLinearGradient(0, 0, 0, 256);
  grad.addColorStop(0, '#3a7bd5');
  grad.addColorStop(0.5, '#a2d0ff');
  grad.addColorStop(1, '#e8f4ff');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 2, 256);
  return new THREE.CanvasTexture(c);
}
scene.background = makeSkyTexture();
scene.fog = new THREE.Fog(0xbfd9ff, 25, 130);

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 1.7, 0);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
document.body.appendChild(renderer.domElement);

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

// ---------- Освещение ----------
const hemi = new THREE.HemisphereLight(0xbcd8ff, 0x554433, 0.7);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xfff4e0, 1.2);
sun.position.set(40, 60, 25);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -65; sun.shadow.camera.right = 65;
sun.shadow.camera.top = 65; sun.shadow.camera.bottom = -65;
scene.add(sun);

// ---------- Текстуры (процедурные, без внешних файлов) ----------
function makeCheckerTexture(colorA, colorB, size = 8) {
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const ctx = c.getContext('2d');
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      ctx.fillStyle = (x + y) % 2 === 0 ? colorA : colorB;
      ctx.fillRect(x * (64 / size), y * (64 / size), 64 / size, 64 / size);
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  return tex;
}
function makeBrickTexture() {
  const c = document.createElement('canvas');
  c.width = 128; c.height = 128;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#c9ad7f';
  ctx.fillRect(0, 0, 128, 128);
  ctx.strokeStyle = 'rgba(120,95,60,0.5)';
  ctx.lineWidth = 3;
  for (let y = 0; y < 128; y += 16) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(128, y); ctx.stroke();
    const offset = (y / 16) % 2 === 0 ? 0 : 16;
    for (let x = offset; x < 128; x += 32) {
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + 16); ctx.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(6, 2);
  return tex;
}

const groundTex = makeCheckerTexture('#d8c9a3', '#cbb98a', 16);
groundTex.repeat.set(16, 16);
const groundMat = new THREE.MeshStandardMaterial({ map: groundTex, roughness: 0.95 });
const ground = new THREE.Mesh(new THREE.PlaneGeometry(120, 120), groundMat);
ground.rotation.x = -Math.PI / 2;
ground.receiveShadow = true;
scene.add(ground);

const wallMat = new THREE.MeshStandardMaterial({ map: makeBrickTexture(), roughness: 0.9 });
function addWall(x, z, w, d, h = 6) {
  const wall = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), wallMat);
  wall.position.set(x, h / 2, z);
  wall.castShadow = true;
  wall.receiveShadow = true;
  scene.add(wall);
  return wall;
}
addWall(0, -60, 120, 2);
addWall(0, 60, 120, 2);
addWall(-60, 0, 2, 120);
addWall(60, 0, 2, 120);

const crateMat = new THREE.MeshStandardMaterial({ color: 0xa9834f, roughness: 0.8 });
const cratePositions = [
  [0, 0], [8, 5], [-8, -5], [15, -10], [-15, 10], [5, -15], [-5, 15], [20, 0], [-20, 0], [0, 20], [0, -20]
];
const obstacles = [];
cratePositions.forEach(([x, z]) => {
  const size = 2.5 + Math.random() * 1.8;
  const crate = new THREE.Mesh(new THREE.BoxGeometry(size, size, size), crateMat);
  crate.position.set(x, size / 2, z);
  crate.rotation.y = Math.random() * 0.4;
  crate.castShadow = true;
  crate.receiveShadow = true;
  scene.add(crate);
  obstacles.push(crate);
});

function addSpawnMarker(x, z, color) {
  const marker = new THREE.Mesh(
    new THREE.CylinderGeometry(3, 3, 0.1, 24),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.3 })
  );
  marker.position.set(x, 0.06, z);
  scene.add(marker);
}
addSpawnMarker(-10, -10, 0x5aa9ff);
addSpawnMarker(10, 10, 0xffb15a);

// ---------- Оружие от первого лица ----------
const gunGroup = new THREE.Group();
const gunMat = new THREE.MeshStandardMaterial({ color: 0x2a2a2a, metalness: 0.6, roughness: 0.4 });
const gunBody = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.14, 0.55), gunMat);
gunBody.position.set(0.28, -0.28, -0.55);
gunGroup.add(gunBody);
const gunBarrel = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.3, 8), gunMat);
gunBarrel.rotation.x = Math.PI / 2;
gunBarrel.position.set(0.28, -0.24, -0.9);
gunGroup.add(gunBarrel);
const muzzleFlash = new THREE.PointLight(0xffaa33, 0, 4);
muzzleFlash.position.set(0.28, -0.24, -1.05);
gunGroup.add(muzzleFlash);
camera.add(gunGroup);
scene.add(camera);

// ---------- Управление ----------
let pitch = 0, yaw = 0;
const keys = {};
let velY = 0;
let onGround = true;
const moveSpeed = 6;
const jumpForce = 6.5;
const gravity = 16;
let canShoot = true;
let isAlive = false;
let ammo = 30, reserve = 90;
let scoreboardOpen = false;

document.addEventListener('keydown', e => {
  keys[e.code] = true;
  if (e.code === 'Tab') { e.preventDefault(); showScoreboard(true); }
  if (e.code === 'KeyR') reload();
});
document.addEventListener('keyup', e => {
  keys[e.code] = false;
  if (e.code === 'Tab') showScoreboard(false);
});

renderer.domElement.addEventListener('click', () => {
  if (isAlive) renderer.domElement.requestPointerLock();
});

document.addEventListener('mousemove', (e) => {
  if (document.pointerLockElement !== renderer.domElement) return;
  const sens = 0.0022;
  yaw -= e.movementX * sens;
  pitch -= e.movementY * sens;
  pitch = Math.max(-Math.PI / 2 + 0.01, Math.min(Math.PI / 2 - 0.01, pitch));
  camera.rotation.order = 'YXZ';
  camera.rotation.y = yaw;
  camera.rotation.x = pitch;
});

document.addEventListener('mousedown', (e) => {
  if (e.button !== 0) return;
  if (document.pointerLockElement !== renderer.domElement) return;
  shoot();
});

function reload() {
  if (!isAlive || reserve <= 0 || ammo === 30) return;
  const needed = 30 - ammo;
  const take = Math.min(needed, reserve);
  ammo += take;
  reserve -= take;
  updateAmmoUI();
  beep(220, 0.2, 'sine', 0.08);
}

function collides(x, z) {
  for (const o of obstacles) {
    const dx = Math.abs(x - o.position.x);
    const dz = Math.abs(z - o.position.z);
    const half = o.geometry.parameters.width / 2 + 0.5;
    if (dx < half && dz < half) return true;
  }
  if (x < -58 || x > 58 || z < -58 || z > 58) return true;
  return false;
}

function updateMovement(dt) {
  if (!isAlive) return;
  const forward = new THREE.Vector3(Math.sin(yaw), 0, Math.cos(yaw)).multiplyScalar(-1);
  const right = new THREE.Vector3(Math.sin(yaw + Math.PI / 2), 0, Math.cos(yaw + Math.PI / 2)).multiplyScalar(-1);

  let move = new THREE.Vector3();
  if (keys['KeyW']) move.add(forward);
  if (keys['KeyS']) move.sub(forward);
  if (keys['KeyA']) move.sub(right);
  if (keys['KeyD']) move.add(right);
  if (move.lengthSq() > 0) move.normalize().multiplyScalar(moveSpeed * dt);

  const newX = camera.position.x + move.x;
  const newZ = camera.position.z + move.z;
  if (!collides(newX, camera.position.z)) camera.position.x = newX;
  if (!collides(camera.position.x, newZ)) camera.position.z = newZ;

  // прыжок и гравитация
  if (keys['Space'] && onGround) {
    velY = jumpForce;
    onGround = false;
  }
  velY -= gravity * dt;
  camera.position.y += velY * dt;
  if (camera.position.y <= 1.7) {
    camera.position.y = 1.7;
    velY = 0;
    onGround = true;
  }

  // лёгкое покачивание оружия при ходьбе
  const walking = move.lengthSq() > 0 && onGround;
  const t = performance.now() / 1000;
  gunGroup.position.y = walking ? Math.sin(t * 8) * 0.015 : 0;
  gunGroup.position.x = walking ? Math.cos(t * 4) * 0.008 : 0;

  socket.emit('move', { x: camera.position.x, y: camera.position.y, z: camera.position.z, rotY: yaw });
}

// ---------- Стрельба ----------
const raycaster = new THREE.Raycaster();
const crosshair = document.getElementById('crosshair');

function shoot() {
  if (!canShoot || !isAlive) return;
  if (ammo <= 0) { beep(90, 0.1, 'square', 0.08); return; }
  canShoot = false;
  ammo--;
  updateAmmoUI();
  setTimeout(() => canShoot = true, 130);

  sfxShoot();
  flashMuzzle();
  gunGroup.position.z = 0.06;
  setTimeout(() => gunGroup.position.z = 0, 60);

  raycaster.setFromCamera({ x: 0, y: 0 }, camera);
  const targets = Object.values(otherPlayers).map(p => p.mesh);
  const hits = raycaster.intersectObjects(targets, true);
  if (hits.length > 0) {
    let obj = hits[0].object;
    while (obj.parent && !obj.userData.playerId) obj = obj.parent;
    const targetId = obj.userData.playerId;
    if (targetId) {
      socket.emit('shoot', { targetId, damage: 25 });
      crosshair.classList.add('hit');
      setTimeout(() => crosshair.classList.remove('hit'), 120);
    }
  }
}

function flashMuzzle() {
  muzzleFlash.intensity = 3;
  setTimeout(() => muzzleFlash.intensity = 0, 50);
}

function updateAmmoUI() {
  const el = document.getElementById('ammoVal');
  el.textContent = ammo;
  el.className = ammo <= 5 ? 'low' : '';
}

// ---------- Другие игроки ----------
function createPlayerMesh(team) {
  const color = team === 'CT' ? 0x5aa9ff : 0xffb15a;
  const group = new THREE.Group();

  const body = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.4, 1.2, 4, 8),
    new THREE.MeshStandardMaterial({ color, roughness: 0.6 })
  );
  body.position.y = 1.0;
  body.castShadow = true;
  group.add(body);

  const vest = new THREE.Mesh(
    new THREE.BoxGeometry(0.85, 0.7, 0.5),
    new THREE.MeshStandardMaterial({ color: 0x333333, roughness: 0.7 })
  );
  vest.position.y = 1.15;
  vest.castShadow = true;
  group.add(vest);

  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.3, 16, 16),
    new THREE.MeshStandardMaterial({ color: 0xffdbac })
  );
  head.position.y = 1.85;
  head.castShadow = true;
  group.add(head);

  const gun = new THREE.Mesh(
    new THREE.BoxGeometry(0.12, 0.12, 0.5),
    new THREE.MeshStandardMaterial({ color: 0x222222 })
  );
  gun.position.set(0.4, 1.1, -0.3);
  group.add(gun);

  return group;
}

function addOrUpdatePlayer(p) {
  if (p.id === myId) return;
  if (!otherPlayers[p.id]) {
    const mesh = createPlayerMesh(p.team);
    mesh.userData.playerId = p.id;
    mesh.traverse(o => o.userData.playerId = p.id);
    scene.add(mesh);
    otherPlayers[p.id] = { mesh, data: p };
  }
  const entry = otherPlayers[p.id];
  entry.data = p;
  entry.mesh.position.set(p.x, 0, p.z);
  entry.mesh.rotation.y = p.rotY;
  entry.mesh.visible = p.alive;
}

function removePlayer(id) {
  const entry = otherPlayers[id];
  if (entry) { scene.remove(entry.mesh); delete otherPlayers[id]; }
}

// ---------- HUD ----------
const hpFill = document.getElementById('healthBarFill');
const hpText = document.getElementById('healthText');
const scoreCTEl = document.getElementById('scoreCT');
const scoreTEl = document.getElementById('scoreT');
const roundTimerEl = document.getElementById('roundTimer');
const killfeed = document.getElementById('killfeed');
const hud = document.getElementById('hud');
const vignette = document.getElementById('vignette');
const deathScreen = document.getElementById('deathScreen');
const respawnTimerEl = document.getElementById('respawnTimer');

function setHealth(hp) {
  hp = Math.max(0, hp);
  hpFill.style.width = hp + '%';
  hpText.textContent = hp + ' HP';
}

function addKillFeed(text) {
  const line = document.createElement('div');
  line.textContent = text;
  killfeed.prepend(line);
  setTimeout(() => line.remove(), 5000);
}

function flashDamage() {
  vignette.classList.add('dmg');
  setTimeout(() => vignette.classList.remove('dmg'), 200);
}

// ---------- Скорборд ----------
function showScoreboard(open) {
  scoreboardOpen = open;
  const sb = document.getElementById('scoreboard');
  if (open) {
    const ctBody = document.getElementById('scoreCTBody');
    const tBody = document.getElementById('scoreTBody');
    ctBody.innerHTML = ''; tBody.innerHTML = '';
    const all = [{ id: myId, name: myName + ' (ты)', team: myTeam, kills: myKills, deaths: myDeaths }];
    for (const id in otherPlayers) all.push(otherPlayers[id].data);
    all.forEach(p => {
      const row = document.createElement('tr');
      row.innerHTML = `<td>${p.name}</td><td>${p.kills || 0}</td><td>${p.deaths || 0}</td><td>—</td>`;
      (p.team === 'CT' ? ctBody : tBody).appendChild(row);
    });
    sb.style.display = 'flex';
  } else {
    sb.style.display = 'none';
  }
}
let myKills = 0, myDeaths = 0;

// ---------- Мини-карта ----------
const mmCanvas = document.getElementById('minimap');
const mmCtx = mmCanvas.getContext('2d');
function drawMinimap() {
  mmCtx.clearRect(0, 0, 140, 140);
  const scale = 140 / 120; // мир 120x120
  function worldToMap(x, z) { return { mx: 70 + x * scale, my: 70 + z * scale }; }

  // препятствия
  mmCtx.fillStyle = 'rgba(255,255,255,0.15)';
  obstacles.forEach(o => {
    const { mx, my } = worldToMap(o.position.x, o.position.z);
    mmCtx.fillRect(mx - 3, my - 3, 6, 6);
  });

  // я
  if (isAlive) {
    const { mx, my } = worldToMap(camera.position.x, camera.position.z);
    mmCtx.fillStyle = '#2ecc71';
    mmCtx.beginPath(); mmCtx.arc(mx, my, 4, 0, Math.PI * 2); mmCtx.fill();
    mmCtx.strokeStyle = '#2ecc71';
    mmCtx.beginPath(); mmCtx.moveTo(mx, my);
    mmCtx.lineTo(mx - Math.sin(yaw) * 10, my - Math.cos(yaw) * 10);
    mmCtx.stroke();
  }

  // остальные (только своя команда — реалистичный "радар")
  for (const id in otherPlayers) {
    const p = otherPlayers[id].data;
    if (!p.alive || p.team !== myTeam) continue;
    const { mx, my } = worldToMap(p.x, p.z);
    mmCtx.fillStyle = p.team === 'CT' ? '#5aa9ff' : '#ffb15a';
    mmCtx.beginPath(); mmCtx.arc(mx, my, 3.5, 0, Math.PI * 2); mmCtx.fill();
  }
}

// ---------- Чат ----------
const chatBox = document.getElementById('chatBox');
const chatInput = document.getElementById('chatInput');
document.addEventListener('keydown', (e) => {
  if (e.code === 'Enter') {
    if (chatInput.style.display === 'block') {
      if (chatInput.value.trim()) socket.emit('chat', chatInput.value.trim());
      chatInput.value = '';
      chatInput.style.display = 'none';
      renderer.domElement.requestPointerLock();
    } else if (isAlive) {
      chatInput.style.display = 'block';
      chatInput.focus();
    }
  }
});
socket.on('chat', ({ name, team, text }) => {
  const line = document.createElement('div');
  line.style.color = team === 'CT' ? '#5aa9ff' : '#ffb15a';
  line.textContent = `${name}: `;
  const span = document.createElement('span');
  span.style.color = '#fff';
  span.textContent = text;
  line.appendChild(span);
  chatBox.appendChild(line);
  while (chatBox.children.length > 6) chatBox.removeChild(chatBox.firstChild);
  setTimeout(() => { if (line.parentNode) line.remove(); }, 8000);
});

// ---------- Сокет-события ----------
socket.on('joined', ({ id, team, state }) => {
  myId = id;
  myTeam = team;
  isAlive = true;
  menu.style.display = 'none';

  const me = state.players[id];
  camera.position.set(me.x, me.y, me.z);
  setHealth(me.health);
  scoreCTEl.textContent = state.score.CT;
  scoreTEl.textContent = state.score.T;

  for (const pid in state.players) if (pid !== id) addOrUpdatePlayer(state.players[pid]);
  hud.textContent = `${me.name} · ${team}`;
  sfxRespawn();
});

socket.on('player_joined', (p) => addOrUpdatePlayer(p));
socket.on('player_moved', (p) => addOrUpdatePlayer(p));
socket.on('player_left', (id) => removePlayer(id));

socket.on('player_damaged', ({ id, health, by }) => {
  if (id === myId) { setHealth(health); flashDamage(); sfxDamage(); }
  else if (otherPlayers[id]) otherPlayers[id].data.health = health;
  if (by === myId) sfxHit();
});

socket.on('player_killed', ({ victim, killer, score }) => {
  scoreCTEl.textContent = score.CT;
  scoreTEl.textContent = score.T;
  const killerName = killer === myId ? 'Ты' : (otherPlayers[killer]?.data.name || '???');
  const victimName = victim === myId ? 'Тебя' : (otherPlayers[victim]?.data.name || '???');
  addKillFeed(`💀 ${killerName} → ${victimName}`);

  if (killer === myId) { myKills++; sfxKill(); }

  if (victim === myId) {
    myDeaths++;
    isAlive = false;
    document.exitPointerLock();
    setHealth(0);
    deathScreen.style.display = 'flex';
    let t = 3;
    respawnTimerEl.textContent = `Возрождение через ${t}...`;
    const iv = setInterval(() => {
      t--;
      if (t <= 0) { clearInterval(iv); deathScreen.style.display = 'none'; }
      else respawnTimerEl.textContent = `Возрождение через ${t}...`;
    }, 1000);
  } else if (otherPlayers[victim]) {
    otherPlayers[victim].mesh.visible = false;
  }
});

socket.on('player_respawned', (p) => {
  if (p.id === myId) {
    isAlive = true;
    ammo = 30; reserve = 90; updateAmmoUI();
    camera.position.set(p.x, p.y, p.z);
    setHealth(p.health);
    sfxRespawn();
  } else if (otherPlayers[p.id]) {
    otherPlayers[p.id].mesh.visible = true;
    addOrUpdatePlayer(p);
  }
});

socket.on('round_end', ({ winner, score }) => {
  addKillFeed(`🏁 Раунд завершён! Победитель: ${winner} (${score.CT}:${score.T})`);
});

socket.on('new_round', ({ players, roundEndsAt }) => {
  scoreCTEl.textContent = 0;
  scoreTEl.textContent = 0;
  const me = players[myId];
  if (me) {
    isAlive = true;
    camera.position.set(me.x, me.y, me.z);
    setHealth(me.health);
    ammo = 30; reserve = 90; updateAmmoUI();
    deathScreen.style.display = 'none';
  }
  for (const pid in players) if (pid !== myId) addOrUpdatePlayer(players[pid]);
});

setInterval(() => {
  // локальный обратный отсчёт раунда (примерный, синхронизируется событиями сервера)
}, 1000);

// ---------- Игровой цикл ----------
let last = performance.now();
function animate() {
  requestAnimationFrame(animate);
  const now = performance.now();
  const dt = Math.min((now - last) / 1000, 0.05);
  last = now;
  updateMovement(dt);
  drawMinimap();
  renderer.render(scene, camera);
}
animate();
